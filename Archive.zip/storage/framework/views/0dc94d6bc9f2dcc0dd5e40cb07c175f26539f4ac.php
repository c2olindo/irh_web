<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('page_styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('irh_assets/vendor/jquery.tagsinput/src/jquery.tagsinput.css')); ?>">
<style>
    #user_name
    {
        font-size: 25px;
        padding-left: 20px;
        position: absolute;
        bottom: 48px;
    }
    #profile_picture 
    {
      position: relative;
      display: inline-block;
    }
    #profile_picture_overlay
    {
      position: absolute;
      top: 0;
      background: #333;
      width: 100%;
      height: 100%;
      opacity: 0.5;
      border-radius: .375rem;
      display: none;
    }

    #profile_picture:hover #profile_picture_overlay
    {
      cursor: pointer;
      display: block !important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Header -->
<div class="page-header row no-gutters py-4">
    <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
        <span class="text-uppercase page-subtitle">Islamic Resource Hub</span>
        <h3 class="page-title"><?php echo e($user->full_name); ?> 's Profile </h3>
    </div>
</div>
<!-- End Page Header -->
<!-- Small Stats Blocks -->
<div class="row">
    <div class="col-lg col-md-12 col-sm-12 mb-4">
        <div class="card">
            <div class="card-header border-bottom">
                    <h6 class="m-0">My Profile</h6>
            </div>
            <div class="card-body p-0 d-flex">
                <div class="card w-100">
                    <div class="card-header bg-primary text-white" style="height: 150px;">
                        <div class="container-fluid w-100">
                            <div class="row">
                                <div class="col-md-8 profile_pictur_container mt-5">
                                    <div id="profile_picture">
                                      <img src="<?php echo e(asset($user->profile_picture_path)); ?>" alt="" class="img-thumbnail" width="120px"><span id="user_name"><?php echo e($user->username); ?></span>
                                      <div id="profile_picture_overlay" class="text-center pt-4">
                                       <a href="#" style="color:#fff;" data-toggle="modal" data-target="#updateProfilePictureModal">
                                         <i class="material-icons" style="font-size: 3rem;">
                                           camera_alt
                                         </i>
                                       </a>
                                      </div>
                                    </div>
                                </div>
                                <div class="col-md-4 text-right">
                                    <a href="<?php echo e(route('dashboard.user.profile')); ?>?action=edit" style="font-size: 25px;color:white;">
                                    <i class="material-icons">
                                    create
                                    </i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                       <div class="about_section py-4">
                           <?php if(\Request::has('action') && \Request::get('action') == 'edit'): ?>
                            <p><strong>Please note that all information underneath will be visible to other users of the website except that which you choose to ’Keep private’.</strong></p>
                                <form action="<?php echo e(route('dashboard.user.profile.update')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="first_name">First Name <span>( Private ? <input type="checkbox" name="private[first_name]" value="first_name" <?php echo e($user->isPrivate('first_name')?'checked':''); ?>> )</span></label>
                                        <input type="text" class="form-control" name="first_name" value="<?php echo e($user->first_name); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="last_name">Last Name <span>( Private ? <input type="checkbox" name="private[last_name]"  value="last_name" <?php echo e($user->isPrivate('last_name')?'checked':''); ?>> )</span></label>
                                        <input type="text" class="form-control" name="last_name" value="<?php echo e($user->last_name); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="address">Position <span>( Private ? <input type="checkbox" name="private[position]"  value="address" <?php echo e($user->isPrivate('position')?'checked':''); ?>> )</span></label>
                                        <input type="text" class="form-control" name="position" value="<?php echo e($user->position); ?>" placeholder="E.g Teacher">
                                    </div>
                                    <div class="form-group">
                                        <label for="city">Working in <span>( Private ? <input type="checkbox" name="private[working_in]"  value="city" <?php echo e($user->isPrivate('working_in')?'checked':''); ?>> )</span></label>
                                        <input type="text" class="form-control" name="working_in" value="<?php echo e($user->working_in); ?>" placeholder="e.g High School">
                                    </div>
                                    <div class="form-group">
                                        <label for="city">Specialist subjects <small>(separate by comma)</small> <span>( Private ? <input type="checkbox" name="private[subjects]"  value="city" <?php echo e($user->isPrivate('subjects')?'checked':''); ?>> )</span></label>
                                        <input id="tags_1" type="text" class="tags form-control" value="<?php echo e($user->subjects); ?>" name="subjects" placeholder="e.g Arabic, Sociology" />
                                    </div>
                                    <div class="form-group">
                                        <label for="country">Country <span>( Private ? <input type="checkbox" name="private[country]"  value="country" <?php echo e($user->isPrivate('country')?'checked':''); ?>> )</span></label>
                                        <input type="text" class="form-control" name="country" value="<?php echo e($user->country); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="about_me">About Me <span>( Private ? <input type="checkbox" name="private[about_me]"  value="about_me" <?php echo e($user->isPrivate('about_me')?'checked':''); ?>> )</span></label>
                                        <textarea name="about_me" rows="3" class="form-control"><?php echo e($user->about_me); ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" class="btn btn-accent" value="Update Profile">
                                        <a href="<?php echo e(route('dashboard.user.profile')); ?>" class="btn btn-danger">Cancel</a>
                                    </div>
                                </form>
                           <?php else: ?>
                           <?php if(($user->first_name !== null)OR($user->about_me !== null)): ?>
                           <h5 class="m-0 pt-3">About Me:</h5>
                           <p class="text-justify"><?php echo $user->about_me; ?></p>
                           <hr>
                           <div class="info py-4">
                               <ul class="list-group">
                                   <li class="list-group-item"><i class="material-icons">location_on</i> Position: <?php echo e($user->position ?? 'N/A'); ?></li>
                                   <li class="list-group-item"><i class="material-icons">location_city</i> Working in: <?php echo e($user->working_in ?? 'N/A'); ?></li>
                                   <li class="list-group-item"><i class="material-icons">location_city</i>  Subjects Specialized: <?php echo e($user->subjects ?? 'N/A'); ?></li>
                                   <li class="list-group-item"><i class="material-icons">flag</i> Country: <?php echo e($user->country ?? 'N/A'); ?></li>
                               </ul>
                           </div>
                           <?php else: ?>
                           <div class="alert alert-info"><h6 class="m-0 text-white">Please Update Your Profile</h6></div>
                           <?php endif; ?>
                           <?php endif; ?>
                       </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal" id="updateProfilePictureModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Update Profile Picture</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form action="<?php echo e(route('dashboard.user.profilepicture.update')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="profile_picture_uploader">Upload New Profile Picture</label>
            <input type="file" name="profile_picture_uploader" class="form-control" required>
          </div>
          <div class="form-group">
            <input type="submit" class="btn btn-accent" value="Upload">
          </div>
        </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_scripts'); ?>
<script src="<?php echo e(asset('irh_assets/vendor/jquery.tagsinput/src/jquery.tagsinput.js')); ?>"></script>
<script>
  $(document).ready(function(){
    $("#tags_1").tagsInput({width:"auto",'defaultText':'Subjects'});
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /Users/Mac/Sites/irh/resources/views/dashboard/users/profile/index.blade.php */ ?>