<?php echo e($slot); ?>


<?php /* /Users/Mac/Sites/irh/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php */ ?>