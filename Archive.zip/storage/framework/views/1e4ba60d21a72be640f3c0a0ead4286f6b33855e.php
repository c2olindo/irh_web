 <aside class="main-sidebar col-12 col-md-3 col-lg-2 px-0">
          <div class="main-navbar">
            <nav class="navbar align-items-stretch navbar-light bg-white flex-md-nowrap border-bottom p-0">
              <a class="navbar-brand w-100 mr-0" href="<?php echo e(url('/')); ?>" style="line-height: 25px;">
                <div class="d-table ml-3">
                  <span class="d-none d-md-inline ml-1"><img src="<?php echo e(asset('irh_assets/images/adminlogo.png')); ?>" alt="" width="120px"></span>
                </div>
              </a>
              <a class="toggle-sidebar d-sm-inline d-md-none d-lg-none">
                <i class="material-icons">&#xE5C4;</i>
              </a>
            </nav>
          </div>
          <div class="nav-wrapper">
            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link <?php echo e((\Request::route()->getName() == 'dashboard.index') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard.index')); ?>">
                  <i class="material-icons">edit</i>
                  <span>Dashboard</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e((\Request::route()->getName() == 'dashboard.resources.upload') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard.resources.upload')); ?>">
                  <i class="material-icons">cloud_upload</i>
                  <span>Upload New Resource</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e((\Request::route()->getName() == 'dashboard.resources.index') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard.resources.index')); ?>">
                  <i class="material-icons">speaker_notes</i>
                  <span>All Resources</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e((\Request::route()->getName() == 'dashboard.resources.categories.index') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard.resources.categories.index')); ?>">
                  <i class="material-icons">list</i>
                  <span>Resource Categories</span>
                </a>
              </li>
             <li class="nav-item">
                <a class="nav-link <?php echo e((\Request::route()->getName() == 'dashboard.resources.tags.index') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard.resources.tags.index')); ?>">
                  <i class="material-icons">loyalty</i>
                  <span>Resource Tags</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e((\Request::route()->getName() == 'dashboard.resources.flagged') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard.resources.flagged')); ?>">
                  <i class="material-icons">flag</i>
                  <span>Flagged Resources</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e((\Request::route()->getName() == 'dashboard.users.index') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard.users.index')); ?>">
                  <i class="material-icons">supervisor_account</i>
                  <span>Users</span>
                </a>
              </li>
              
              <li class="nav-item">
                <a class="nav-link <?php echo e((\Request::route()->getName() == 'dashboard.subscribers') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard.subscribers')); ?>">
                  <i class="material-icons">supervisor_account</i>
                  <span>Subscribers</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e((\Request::route()->getName() == 'dashboard.donations') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard.donations')); ?>">
                  <i class="material-icons">money</i>
                  <span>Donations</span>
                </a>
              </li>
            </ul>
            <?php endif; ?>
            <?php if(auth()->check() && auth()->user()->hasRole('user')): ?>
             <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link <?php echo e((\Request::route()->getName() == 'dashboard.index') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard.index')); ?>">
                  <i class="material-icons">edit</i>
                  <span>Dashboard</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e((\Request::route()->getName() == 'dashboard.resources.upload') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard.resources.upload')); ?>">
                  <i class="material-icons">cloud_upload</i>
                  <span>Upload New Resource</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e((\Request::route()->getName() == 'dashboard.resources.user') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard.resources.user')); ?>">
                  <i class="material-icons">speaker_notes</i>
                  <span>My Resources</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link <?php echo e((\Request::route()->getName() == 'dashboard.user.profile') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard.user.profile')); ?>">
                  <i class="material-icons">account_circle</i>
                  <span>My Profile</span>
                </a>
              </li>
            </ul>
            <?php endif; ?>
          </div>
        </aside>
<?php /* /Users/Mac/Sites/irh/resources/views/dashboard/layouts/sidebar.blade.php */ ?>