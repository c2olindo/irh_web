<?php /* /Users/Mac/Sites/irh/resources/views/resources.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<header id="resources-header" style="background:linear-gradient(rgba(30, 169, 231, 0.5),rgba(51, 57, 61, 0.5)), url(<?php echo e(asset('irh_assets/images/resourcebg.jpg')); ?>);height: 800px;background-size: cover;background-attachment: fixed;background-position:top center;">
	<div class="header-content container">
		<div class="row">
			<div class="col-md-6">
				<div class="card card-body">
					<form action="<?php echo e(route('theme.resources.filtered')); ?>" method="GET">
						<div class="form-group">
							<input type="text" class="form-control" placeholder="Search for resources .." name="keyword">
						</div>
						<div class="form-group">
							<select name="age_group" id="" class="form-control">
								<option value="" selected disabled>--Filter By Age Group--</option>
								<?php $__currentLoopData = $age_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($ag->id); ?>"><?php echo e($ag->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						<div class="form-group">
							<select name="resource_type" id="" class="form-control">
								<option value="" selected disabled>--Filter By Resource Type--</option>
								<?php $__currentLoopData = $resource_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($rt->id); ?>"><?php echo e($rt->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
						<div class="form-group">
							<input type="submit" class="btn bg-blue btn-block">
						</div>
					</form>
					<div class="d-flex flex-row justify-content-between">
						<div class="flex-column">
							<small>Have a new resource to share?</small>
						</div>
						<div class="flex-column">
							&nbsp;
						</div>
						<div class="flex-column">
							<a href="<?php echo e(route('dashboard.resources.upload')); ?>" class="btn bg-yellow">Upload a resource</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</header>
<section id="resources" class="text-center py-5">
	<div class="container">
		<h1 class="pb-5 heading">Resources</h1>
		<div class="row">
			<?php $__empty_1 = true; $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div class="col-md-3 mb-4">
				<div class="resourcebox">
					<div class="card">
						<a href="<?php echo e(route('theme.singleresource',$resource)); ?>">
					  <img class="card-img-top" src="<?php echo e($resource->preview_attachment_path); ?>" alt="Card image cap" style="position: relative;"></a>
					  <span style="position: absolute;top: -1;right: 10px;">
					  	<?php if(!$resource->isResourceSavedByLoggedInUser()): ?>
					  	<a href="<?php echo e(route('theme.saveresource',$resource)); ?>">
					  	<img src="<?php echo e(asset('irh_assets/images/savelogo.png')); ?>" alt="" width="25px" data-toggle="tooltip" data-placement="top" title="save for later">
					  	</a>
					  	<?php else: ?>
					  	<img src="<?php echo e(asset('irh_assets/images/savedlogo.png')); ?>" alt="" width="25px">
					  	<?php endif; ?>
					  </span>
					  <div class="card-body">
					  	<div class="pb-4"><img src="<?php echo e(asset('irh_assets/images/avatar.png')); ?>" alt="" width="30px" class="rounded-circle"><span class="ml-3"><?php echo e($resource->user->full_name); ?></span></div>
					    <a href="<?php echo e(route('theme.singleresource',$resource)); ?>" class="text-muted"><h5 class="card-title"><?php echo e($resource->title); ?></h5></a>
					  </div>
					  <div class="card-footer">
					  	<div style="display: grid;">
					  		<div style="grid-column: 1;border-right: 1px solid #333;"><small>VIEWS</small><br><?php echo e($resource->views); ?></div>
					  		<div style="grid-column: 2;border-right: 1px solid #333;"><small>DOWNLOADS</small><br><?php echo e($resource->downloads); ?></div>
					  		<div style="grid-column: 3;"><small>LIKES</small><br><?php echo e($resource->likes->count()); ?></div>
					  	</div>
					  </div>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<div class="col-md-4 offset-md-4">
				<h3>No Resources Found</h3>
			</div>
			<?php endif; ?>
		</div>
		<div class="row mt-4">
			<div class="col-md-4 offset-md-5">
				<?php echo e($resources->links()); ?>

			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>