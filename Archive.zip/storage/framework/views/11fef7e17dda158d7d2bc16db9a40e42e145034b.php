<nav class="navbar align-items-stretch navbar-light flex-md-nowrap p-0">
  <form action="#" class="main-navbar__search w-100 d-none d-md-flex d-lg-flex">
  
  </form>
  <ul class="navbar-nav border-left flex-row ">
        <li class="nav-item border-right dropdown notifications">
          <a class="nav-link nav-link-icon text-center" href="<?php echo e(route('dashboard.messages.index')); ?>">
            <div class="nav-link-icon__wrapper">
              <i class="material-icons">chat</i>
              <span class="badge badge-pill badge-danger"><?php echo e(Auth::user()->getUnreadUserMessagesCount()); ?></span>
            </div>
          </a>
        </li>
        <?php if(auth()->guard()->check()): ?>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-nowrap px-3" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
            <img class="user-avatar rounded-circle mr-2" src="<?php echo e(asset('irh_assets/images/avatar.png')); ?>" alt="User Avatar">
            <span class="d-none d-md-inline-block"><?php echo e(Auth::user()->username); ?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
          </a>
          <div class="dropdown-menu dropdown-menu-small">
            <a class="dropdown-item text-danger" href="<?php echo e(route('dashboard.password')); ?>"><i class="material-icons text-danger">fingerprint</i> Update Password</a>
            <a class="dropdown-item text-danger" href="<?php echo e(route('logout')); ?>"
              onclick="event.preventDefault();
              document.getElementById('logout-form').submit();">
              <i class="material-icons text-danger">&#xE879;</i>
              <?php echo e(__('Logout')); ?>

            </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo csrf_field(); ?>
            </form>

          </div>
        </li>
        <?php else: ?>
        <li class="nav-item dropdown">
          <a class="nav-link text-nowrap px-3 pt-3" href="#">Go to Site</a>
        </li>
        <?php endif; ?>
      </ul>
      <nav class="nav">
        <a href="#" class="nav-link nav-link-icon toggle-sidebar d-md-inline d-lg-none text-center border-left" data-toggle="collapse" data-target=".header-navbar" aria-expanded="false" aria-controls="header-navbar">
          <i class="material-icons">&#xE5D2;</i>
        </a>
      </nav>
    </nav>
<?php /* /Users/Mac/Sites/irh/resources/views/dashboard/layouts/nav.blade.php */ ?>