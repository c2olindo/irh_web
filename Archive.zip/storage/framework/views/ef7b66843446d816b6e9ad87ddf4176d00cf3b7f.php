<?php /* /Users/Mac/Sites/irh/resources/views/dashboard/layouts/footer.blade.php */ ?>
<footer class="main-footer d-flex p-2 px-3 bg-white border-top">
  <span class="copyright ml-auto my-auto mr-2">Copyright © <?php echo e(date('Y')); ?>

    <a href="javascript:void(0);" rel="nofollow">Islamic Resource Hub</a>
  </span>
</footer>