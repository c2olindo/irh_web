<?php /* /Users/Mac/Sites/irh/resources/views/emails/contactus.blade.php */ ?>
<?php $__env->startComponent('mail::message'); ?>
<h3>As-salāmu ‘alaykum wa-rahmatullāhi wa-barakātuh</h3>
<div style="padding:20px 0;">
	<?php echo e($message); ?>

</div>

Jazak'Allah Khair,<br>
<?php echo e($fullname); ?>

<?php echo $__env->renderComponent(); ?>
