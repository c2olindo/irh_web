<?php $__env->startComponent('mail::message'); ?>
<h3>As-salāmu ‘alaykum wa-rahmatullāhi wa-barakātuh</h3>
<div style="padding:20px 0;">
	<h4>Your resource with title " <?php echo e($title); ?> " has been rejected because of following reason(s)</h4>
	<h4>Rejection Reason : <?php echo e($reason); ?></h4>
	<p>Additional Details: <?php echo e($details ?? 'N/A'); ?></p>
</div>

Jazak'Allah Khair,<br>
Admin - Islamic Resource Hub
<?php echo $__env->renderComponent(); ?>

<?php /* /Users/Mac/Sites/irh/resources/views/emails/rejectresource.blade.php */ ?>