<?php $__env->startSection('content'); ?>
<section id="resources" class="text-center py-5" style="height: 75.7vh;">
	<div class="container">
		<h1 class="pb-5 heading">Saved Resources</h1>
		<div class="row">
			<?php $__empty_1 = true; $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div class="col-md-3 mb-4">
				<div class="resourcebox">
					<div class="card">
						<a href="<?php echo e(route('theme.singleresource',$resource)); ?>">
					  <img class="card-img-top" src="<?php echo e($resource->preview_attachment_path); ?>" alt="Card image cap" style="position: relative;"></a>
					  <span style="position: absolute;top: -1;right: 10px;">
					  	<a href="<?php echo e(route('theme.unsaveresource',$resource)); ?>">
					  	<img src="<?php echo e(asset('irh_assets/images/unsavedlogo.png')); ?>" alt="" width="25px">
					  	</a>
					  </span>
					  <div class="card-body">
					  	<div class="pb-4"><img src="<?php echo e(asset('irh_assets/images/avatar.png')); ?>" alt="" width="30px" class="rounded-circle"><span class="ml-3"><?php echo e($resource->user->full_name); ?></span></div>
					    <a href="<?php echo e(route('theme.singleresource',$resource)); ?>"><h5 class="card-title text-muted"><?php echo e($resource->title); ?></h5></a>
					  </div>
					  <div class="card-footer">
					  	<div style="display: grid;">
					  		<div style="grid-column: 1;border-right: 1px solid #333;"><small>VIEWS</small><br><?php echo e($resource->views); ?></div>
					  		<div style="grid-column: 2;border-right: 1px solid #333;"><small>DOWNLOADS</small><br><?php echo e($resource->downloads); ?></div>
					  		<div style="grid-column: 3;"><small>LIKES</small><br><?php echo e($resource->likes->count()); ?></div>
					  	</div>
					  </div>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<div class="col-md-12">
				<h4>See a resource that you like? <br> Click on the bookmark in the top right corner of the tile, to add it to your saved resources page. <br> Your bookmarked resources will appear, ready to view later.</h4>
			</div>
			<?php endif; ?>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /Users/Mac/Sites/irh/resources/views/saved-resources.blade.php */ ?>