[<?php echo e($slot); ?>](<?php echo e($url); ?>)

<?php /* /Users/Mac/Sites/irh/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php */ ?>