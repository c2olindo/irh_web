<?php /* /Users/Mac/Sites/irh/resources/views/dashboard/resources/categories/index.blade.php */ ?>
<?php $__env->startSection('title', 'Resource Categories'); ?>
<?php $__env->startSection('content'); ?>
<!-- Page Header -->
<div class="page-header row no-gutters py-4">
    <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
        <span class="text-uppercase page-subtitle">Islamic Resource Hub</span>
        <h3 class="page-title">Resource Categories</h3>
    </div>
</div>
<!-- End Page Header -->
<!-- Small Stats Blocks -->
<div class="row">
   <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
    <div class="card">
      <div class="card-header border-bottom">
          <h6 class="m-0">Add New Resource Category</h6>
      </div>
      <div class="card-body p-3 d-flex">
        <form action="<?php echo e(route('dashboard.resources.categories.store')); ?>" method="POST" class="w-100">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="size_title">Title: *</label>
            <input type="text" name="title" class="form-control <?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" required>
            <?php if($errors->has('title')): ?>
            <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('title')); ?></strong>
            </span>
            <?php endif; ?>
          </div>
          <div class="form-group">
            <input type="submit" class="btn btn-primary" value=" + Add Resource Category">
          </div>
        </form>
      </div>
    </div>
   </div>
   <div class="col-lg-6 col-md-6 col-sm-12 mb-4"></div>
    <div class="col-lg-12 col-md-12 col-sm-12 mb-4">
        <div class="card">
            <div class="card-header border-bottom">
                    <h6 class="m-0">All Resource Categories</a></h6>
            </div>
            <div class="card-body p-0 d-flex">
                <table class="table mb-0">
                      <thead class="bg-light">
                        <tr>
                          <th scope="col" class="border-0">#</th>
                          <th scope="col" class="border-0">Title</th>
                          <th scope="col" class="border-0">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                          <td><?php echo e($loop->iteration); ?></td>
                          <td><?php echo e($cat->title); ?></td>
                          <td>
                              <a href="<?php echo e(route('dashboard.resources.categories.edit',$cat)); ?>" class="badge badge-info">Edit</a>
                              <a href="<?php echo e(route('dashboard.resources.categories.destroy',$cat)); ?>" class="badge badge-danger">Delete</a>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">No Resource Categories Found</td>
                        </tr>
                        <?php endif; ?>
                      </tbody>
                    </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>