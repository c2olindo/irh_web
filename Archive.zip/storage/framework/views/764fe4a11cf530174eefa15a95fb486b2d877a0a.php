<?php $__env->startSection('content'); ?>
<header id="single-resource-header" class="bg-blue py-5" style="height: 400px;">
	<div class="container-fluid" style="margin-top:5%;margin-left: 2%;">
		<?php if(Session::has('successPublish')): ?>
		<div class="row">
			<div class="col-md-8 offset-md-2">
				<div class="alert alert-success">
					<h6>Jazakallahu Khairan for sharing your resource, as part of quality control one of our team members will need to approve of your resource before going live. <br> <a href="#">Click here</a> to find out more about what type of resources will not be approved.</h6>
				</div>
			</div>
		</div>
		<?php else: ?>
		<div class="row">
			<div class="col-md-6 offset-md-3">
				<div class="alert alert-success">
					<?php if($resource->resource_status == 'drafted'): ?>
					<h6>A draft copy of this resource has been saved</h6>
					<?php endif; ?>
					<a href="<?php echo e(route('dashboard.resources.edit',$resource)); ?>" class="btn bg-blue btn-sm"><i class="fas fa-pen"></i> Edit</a>
					<?php if($resource->resource_status == 'drafted'): ?>
					<a href="<?php echo e(route('dashboard.resource.submitforreviewbyuser',$resource)); ?>" class="btn bg-blue btn-sm"><i class="fas fa-check"></i> Submit for review</a>
					<?php elseif($resource->resource_status == 'inreview'): ?>
					<a href="#" class="btn bg-blue btn-sm"><i class="fas fa-info"></i> In-Review</a>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php endif; ?>
		<div class="row">
			<div class="col-md-8 text-left">
				<h3 class="text-white mb-0"><?php echo e(ucwords($resource->title)); ?> (Preview)</h3>
				<div class="py-2" style="border-bottom: 1px solid #ffffff85;">
					<i class="fas fa-star" style="color:var(--yellow-color);"></i>
					<i class="fas fa-star" style="color:var(--yellow-color);"></i>
					<i class="fas fa-star" style="color:var(--yellow-color);"></i>
					<i class="fas fa-star" style="color:var(--yellow-color);"></i>
					<i class="far fa-star"></i>
					<span class="pl-2"><?php echo e($resource->reviews->count()); ?> Review</span>
				</div>
				<div class="py-2">
					<div class="float-left">
						<h5 class="text-white mb-0">Author: <?php echo e(ucwords($resource->user->full_name)); ?></h5>
						<h5 class="text-white mb-0 mt-2">Created at: <?php echo e(date('d-M-Y',strtotime($resource->created_at))); ?></h5>
					</div>
					<div class="float-right">
						<span class="px-2"><i class="fab fa-instagram"></i></span>
						<span class="px-2"><i class="fab fa-facebook"></i></span>
						<span class="px-2"><i class="fab fa-whatsapp"></i></span>
						<span class="px-2"><i class="fab fa-twitter"></i></span>
					</div>
				</div>
			</div>
			<div class="col-md-3">
				<div class="card">
					<div class="card-body">
						<a href="<?php echo e(route('theme.downloadresource',$resource)); ?>" class="btn bg-blue btn-block"><i class="fas fa-download"></i> Download</a>
					</div>
					<div class="card-footer">
						<div class="my-2" style="display: grid;">
							<div style="grid-column: 1;">
								<img src="<?php echo e(asset('irh_assets/images/singlesave.png')); ?>" alt="" width="30px"> <span class="text-muted pl-3">Save for later</span>
							</div>
							<div style="grid-column: 2;">
								<a href="javascript:void(0);" class="btn bg-yellow"><i class="far fa-thumbs-up"></i> Like</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</header>
<section id="single-resource" class="p-5">
	<div class="description">
		<?php echo $resource->description; ?>

	</div>
	<hr>
	<div class="files py-4">
		<h4 class="heading">File(s) Included:</h4>
		<div>
			<figure class="figure">
			  <img src="<?php echo e($resource->cover_attachment_path); ?>" alt="" class="img-thumbnail" width="200px" height="200px">
			  <figcaption class="figure-caption ml-3"><a href="<?php echo e(route('theme.downloadresource',$resource)); ?>"><i class="fas fa-download"></i> Download resource file</a></figcaption>
			</figure>
		</div>
	</div>
	<hr>
	<p>Report a <a href="">Problem</a></p>
	<hr>
	<h4 class="heading">Review(s):
	</h4>
	<div class="reviews">
		<?php $__currentLoopData = $resource->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="review py-4">
			<h6 class="text-muted"><i class="fa fa-angle-right"></i> <?php echo e($rv->user->full_name); ?> <span><?php echo $rv->resourceStarsRatings(); ?></span></h6>
			<p class="ml-3"><?php echo e($rv->review); ?></p>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<hr>
	<h4 class="heading">Tags:</h4>
	<div class="tags py-4">
		<?php $__currentLoopData = $resource->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<span class="bg-blue p-2" style="border-radius:3em;"><?php echo e($tag->name); ?></span>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /Users/Mac/Sites/irh/resources/views/preview-single-resource.blade.php */ ?>