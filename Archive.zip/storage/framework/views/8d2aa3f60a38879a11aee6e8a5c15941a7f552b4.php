<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title><?php echo e(config('app.name', 'Islamic Resource Hub')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
        <meta name="description" content="Islamic Resource Hub">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link href="<?php echo e(asset('irh_assets/vendor/fontawesome/all.min.css')); ?>" rel="stylesheet">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('irh_assets/vendor/bootstrap/bootstrap.min.css')); ?>" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('irh_assets/vendor/toastr/toastr.min.css')); ?>">
        <link href="<?php echo e(asset('irh_assets/vendor/select2/select2.min.css')); ?>" rel="stylesheet" />
        <link rel="stylesheet" id="main-stylesheet" data-version="1.1.0" href="<?php echo e(asset('irh_assets/vendor/shards_dashboard/styles/shards-dashboards.1.1.0.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('irh_assets/vendor/shards_dashboard/styles/extras.1.1.0.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('irh_assets/vendor/dropzone/dropzone.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('irh_assets/vendor/DataTables/datatables.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('irh_assets/vendor/jquery-ui/jquery-ui.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('irh_assets/vendor/summernote/summernote-lite.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('irh_assets/css/custom.css?v=1.0')); ?>">
        <link rel="icon" href="<?php echo e(asset('irh_assets/images/favicon.png')); ?>" type="png" sizes="32x32">
        <?php echo $__env->yieldContent('page_styles'); ?>
        <style>
            .modal-backdrop
            {
              background: rgb(0,0,0,0.5);
            }
        </style>
        <script async defer src="https://buttons.github.io/buttons.js"></script>
    </head>
    <body class="h-100 pr-0">
        <div class="container-fluid">
            <div class="row">
                <?php echo $__env->make('dashboard.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <main class="main-content col-lg-10 col-md-9 col-sm-12 p-0 offset-lg-2 offset-md-3">
                    <div class="main-navbar sticky-top bg-white">
                        <?php echo $__env->make('dashboard.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="main-content-container container-fluid px-4">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                    <?php echo $__env->make('dashboard.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </main>
            </div>
        </div>
        <!-- JS Files -->
        <script src="<?php echo e(asset('irh_assets/vendor/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('irh_assets/vendor/popper/popper.min.js')); ?>" ></script>
        <script src="<?php echo e(asset('irh_assets/vendor/bootstrap/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('irh_assets/vendor/toastr/toastr.min.js')); ?>"></script>
        <script src="<?php echo e(asset('irh_assets/vendor/select2/select2.min.js')); ?>"></script>
        <script src="<?php echo e(asset('irh_assets/vendor/dropzone/dropzone.js')); ?>"></script>
        <script src="<?php echo e(asset('irh_assets/vendor/DataTables/datatables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('irh_assets/vendor/jquery-ui/jquery-ui.min.js')); ?>"></script>
        <script src="<?php echo e(asset('irh_assets/vendor/summernote/summernote-lite.js')); ?>"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>
        <script src="https://unpkg.com/shards-ui@latest/dist/js/shards.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Sharrre/2.0.1/jquery.sharrre.min.js"></script>
        <script src="<?php echo e(asset('irh_assets/vendor/shards_dashboard/scripts/extras.1.1.0.min.js')); ?>"></script>
        <script src="<?php echo e(asset('irh_assets/vendor/shards_dashboard/scripts/shards-dashboards.1.1.0.min.js')); ?>"></script>
        <script src="<?php echo e(asset('irh_assets/js/custom.js?v=1')); ?>"></script>
        <script>
        $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip();
        $(".selectbox").select2({
        placeholder:"--Choose--"
        });
        $('.summernote').summernote();
        });
        </script>
        <?php echo $__env->yieldContent('page_scripts'); ?>
        <?php if(Session::has('error')): ?>
        <script type="text/javascript">
        toastr.error("<?php echo e(Session::get('error')); ?>");
        </script>
        <?php endif; ?>
        <?php if(Session::has('success')): ?>
        <script type="text/javascript">
        toastr.success("<?php echo e(Session::get('success')); ?>");
        </script>
        <?php endif; ?>
        <?php if(Session::has('info')): ?>
        <script type="text/javascript">
        toastr.info("<?php echo e(Session::get('info')); ?>");
        </script>
        <?php endif; ?>
    </body>
</html>
<?php /* /Users/Mac/Sites/irh/resources/views/dashboard/layouts/app.blade.php */ ?>