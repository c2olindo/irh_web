<?php $__env->startSection('content'); ?>
<header id="single-resource-header" class="bg-blue py-5">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-8 text-left">
				<h3 class="text-white mb-0"><?php echo e(ucwords($resource->title)); ?></h3>
				<div class="py-2" style="border-bottom: 1px solid #ffffff85;">
					<i class="fas fa-star" style="color:var(--yellow-color);"></i>
					<i class="fas fa-star" style="color:var(--yellow-color);"></i>
					<i class="fas fa-star" style="color:var(--yellow-color);"></i>
					<i class="fas fa-star" style="color:var(--yellow-color);"></i>
					<i class="far fa-star"></i>
					<span class="pl-2"><?php echo e($resource->reviews->count()); ?> <?php echo e(str_plural('Review',$resource->reviews->count())); ?></span>
				</div>
				<div class="py-2">
					<div class="float-left">
						<h5 class="text-white mb-0">Author: <?php echo e(ucwords($resource->user->full_name)); ?></h5>
						<h5 class="text-white mb-0 mt-2">Created at: <?php echo e(date('d-M-Y',strtotime($resource->created_at))); ?></h5>
					</div>
					<div class="float-right">
						<span class="px-2"><i class="fab fa-instagram"></i></span>
						<span class="px-2"><i class="fab fa-facebook"></i></span>
						<span class="px-2"><i class="fab fa-whatsapp"></i></span>
						<span class="px-2"><i class="fab fa-twitter"></i></span>
					</div>
				</div>
			</div>
			<div class="col-md-3">
				<div class="card">
					<div class="card-body">
						<a href="<?php echo e(route('theme.downloadresource',$resource)); ?>" class="btn bg-blue btn-block"><i class="fas fa-download"></i> Download</a>
					</div>
					<div class="card-footer">
						<div class="my-2" style="display: grid;">
							<div style="grid-column: 1;">
								<?php if(!$resource->isResourceSavedByLoggedInUser()): ?>
								<a href="<?php echo e(route('theme.saveresource',$resource)); ?>">
									<img src="<?php echo e(asset('irh_assets/images/singlesave.png')); ?>" alt="" width="30px"> <span class="text-muted pl-3">Save for later</span>
								</a>
								<?php else: ?>
								<img src="<?php echo e(asset('irh_assets/images/savedlogo.png')); ?>" alt="" width="30px"> Saved
								<?php endif; ?>
								
							</div>
							<div style="grid-column: 2;">
								<?php if(!$resource->isResourceLikedByLoggedInUser()): ?>
								<a href="<?php echo e(route('theme.likeresource',$resource)); ?>" class="btn bg-yellow"><i class="far fa-thumbs-up"></i> Like</a>
								<?php else: ?>
								<a href="javascript:void(0);" class="btn bg-yellow"><i class="fas fa-thumbs-up"></i> Liked</a>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</header>
<section id="single-resource" class="p-5">
	<div class="description">
		<?php echo $resource->description; ?>

	</div>
	<hr>
	<div class="files py-4">
		<h4 class="heading">File(s) Included:</h4>
		<div>
			<figure class="figure">
				<img src="<?php echo e($resource->cover_attachment_path); ?>" alt="" class="img-thumbnail" width="200px" height="200px">
				<figcaption class="figure-caption ml-3"><a href="<?php echo e(route('theme.downloadresource',$resource)); ?>"><i class="fas fa-download"></i> Download resource file</a></figcaption>
			</figure>
		</div>
	</div>
	<hr>
	<?php if(auth()->guard()->check()): ?>
	<p>Report a <a href="" data-toggle="modal" data-target="#flagResourceModal">Problem</a></p>
	<?php if(Session::has('success')): ?>
	<div class="alert alert-success">
		<?php echo e(Session::get('success')); ?>

	</div>
	<?php endif; ?>
	<hr>
	<?php endif; ?>
	<h4 class="heading">Review(s):
	<?php if(auth()->guard()->check()): ?>
	<?php if(!$resource->loggedInUserHasReview()): ?>
	<a href="#" data-toggle="modal" data-target="#addReviewModal" class="btn bg-blue btn-sm">Add a Review</a>
	<?php endif; ?>
	<?php endif; ?>
	</h4>
	<div class="reviews">
		<?php $__currentLoopData = $resource->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="review py-4">
			<h6 class="text-muted"><i class="fa fa-angle-right"></i> <?php echo e($rv->user->full_name); ?> <span><?php echo $rv->resourceStarsRatings(); ?></span>
			<?php if($rv->status == 1): ?>
			<?php if($rv->user_id == Auth::id()): ?>
			&nbsp;&nbsp;<a href="javascript:void(0);" data-toggle="modal" data-target="#editReviewModal<?php echo e($rv->id); ?>" class="text-muted"><i class="fa fa-pen"></i></a>
			<?php endif; ?>
			<?php if(Auth::check() && Auth::user()->hasRole('admin')): ?>
			<a href="<?php echo e(route('theme.deletereviewfromresource',$rv)); ?>" class="text-muted ml-2" onclick="return confirm('Are you sure you want to delete this?');"><i class="fa fa-times"></i></a>
			<?php endif; ?>
			</h6>
			<p class="ml-3"><?php echo e($rv->review); ?></p>
			<?php else: ?>
			</h6>
			<p class="ml-3"><em>This review has been removed by a moderator.</em></p>
			<?php endif; ?>
		</div>
		<div class="modal fade" id="editReviewModal<?php echo e($rv->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">Edit Review</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<form action="<?php echo e(route('theme.updatereviewfromresource',$rv)); ?>" method="POST">
							<?php echo csrf_field(); ?>
							<div class="form-group">
								<label for="">Review</label>
								<textarea name="review" rows="2" class="form-control" placeholder="Review .."><?php echo e($rv->review); ?></textarea>
							</div>
							<div class="form-group">
								<label for="">Rating</label>
								<select name="stars" id="" class="form-control">
									<option value="1" <?php echo e(($rv->stars == 1)?'selected':''); ?>>1 Star</option>
									<option value="2" <?php echo e(($rv->stars == 2)?'selected':''); ?>>2 Star</option>
									<option value="3" <?php echo e(($rv->stars == 3)?'selected':''); ?>>3 Star</option>
									<option value="4" <?php echo e(($rv->stars == 4)?'selected':''); ?>>4 Star</option>
									<option value="5" <?php echo e(($rv->stars == 5)?'selected':''); ?>>5 Star</option>
								</select>
							</div>
							<div class="form-group">
								<input type="submit" class="btn bg-blue" value="Update Review">
							</div>
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<hr>
	<h4 class="heading">Tags:</h4>
	<div class="tags py-4">
		<?php $__currentLoopData = $resource->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<span class="bg-blue p-2" style="border-radius:3em;"><?php echo e($tag->name); ?></span>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<hr>
	<h4 class="heading text-center">Related Resources:</h4>
	<div class="relatedResources py-4 text-center">
		<div class="container">
			<div class="row">
				<?php $__empty_1 = true; $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<div class="col-md-3 mb-4">
					<div class="resourcebox">
						<div class="card">
							<a href="<?php echo e(route('theme.singleresource',$rel)); ?>">
							<img class="card-img-top" src="<?php echo e($rel->preview_attachment_path); ?>" alt="Card image cap" style="position: relative;"></a>
							<span style="position: absolute;top: -1;right: 10px;">
								<?php if(!$rel->isResourceSavedByLoggedInUser()): ?>
								<a href="<?php echo e(route('theme.saveresource',$rel)); ?>">
									<img src="<?php echo e(asset('irh_assets/images/savelogo.png')); ?>" alt="" width="25px" data-toggle="tooltip" data-placement="top" title="save for later">
								</a>
								<?php else: ?>
								<img src="<?php echo e(asset('irh_assets/images/savedlogo.png')); ?>" alt="" width="25px">
								<?php endif; ?>
							</span>
							<div class="card-body">
								<div class="pb-4"><img src="<?php echo e(asset('irh_assets/images/avatar.png')); ?>" alt="" width="30px" class="rounded-circle"><span class="ml-3"><?php echo e($rel->user->full_name); ?></span></div>
								<a href="<?php echo e(route('theme.singleresource',$rel)); ?>" class="text-muted"><h5 class="card-title"><?php echo e($rel->title); ?></h5></a>
							</div>
							<div class="card-footer">
								<div style="display: grid;">
									<div style="grid-column: 1;border-right: 1px solid #333;"><small>VIEWS</small><br><?php echo e($rel->views); ?></div>
									<div style="grid-column: 2;border-right: 1px solid #333;"><small>DOWNLOADS</small><br><?php echo e($rel->downloads); ?></div>
									<div style="grid-column: 3;"><small>LIKES</small><br><?php echo e($rel->likes->count()); ?></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<div class="col-md-4 offset-md-4">
					<h3>No Related Resource</h3>
				</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>
<div class="modal fade" id="addReviewModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Add a Review</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form action="<?php echo e(route('theme.addreviewtoresource')); ?>" method="POST">
					<?php echo csrf_field(); ?>
					<div class="form-group">
						<label for="">Review</label>
						<textarea name="review" rows="2" class="form-control" placeholder="Review .."></textarea>
					</div>
					<div class="form-group">
						<label for="">Rating</label>
						<select name="stars" id="" class="form-control">
							<option value="1">1 Star</option>
							<option value="2">2 Star</option>
							<option value="3">3 Star</option>
							<option value="4">4 Star</option>
							<option value="5">5 Star</option>
						</select>
					</div>
					<div class="form-group">
						<input type="hidden" name="resource_id" value="<?php echo e($resource->id); ?>">
						<input type="submit" class="btn bg-blue" value="Add Review">
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="flagResourceModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Flag this Resource</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form action="<?php echo e(route('theme.flagresource')); ?>" method="POST">
					<?php echo csrf_field(); ?>
					<div class="form-group">
						<label for="">Reason</label>
						<textarea name="reason" rows="2" class="form-control" placeholder="Explain your problem .."></textarea>
					</div>
					<div class="form-group">
						<input type="hidden" name="resource_id" value="<?php echo e($resource->id); ?>">
						<input type="submit" class="btn bg-blue" value="Report">
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /Users/Mac/Sites/irh/resources/views/single-resource.blade.php */ ?>