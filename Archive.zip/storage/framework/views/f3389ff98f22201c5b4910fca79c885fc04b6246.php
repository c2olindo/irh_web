<?php $__env->startSection('title', 'Messages'); ?>
<?php $__env->startSection('page_styles'); ?>
<style>
  .chat-history
  {
    height: 100%;
  }
  .message
  {
    padding:1em;
    border:1px solid transparent;
    border-radius: 30px;
    color:#fff;
    display: inline-block;
  }
  .message.my-message
  {
    background: var(--blue);
  }
  .message.their-message
  {
    background: var(--success);
  }
  .my-message-item
  {
    text-align: right;
  }
  textarea.form-control
  {
    border:none;
    resize: none;
    border-bottom: 1px solid #8a848475;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php 
$message_to_user = null;
if(\Request::has('user'))
{
  $message_to_user = \App\User::find(\Request::get('user'));
  abort_if(!$message_to_user,404);
}
elseif($latest)
{
  if($latest->user_from !== Auth::id())
    $message_to_user = \App\User::find($latest->user_from);
  else
    $message_to_user = \App\User::find($latest->user_to);

  abort_if(!$message_to_user,404);
}

?>
<!-- Page Header -->
<div class="page-header row no-gutters py-4">
    <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
        <span class="text-uppercase page-subtitle">Islamic Resource Hub</span>
        <h3 class="page-title">Messages </h3>
    </div>
</div>
<!-- End Page Header -->
<!-- Small Stats Blocks -->
<div class="row">
    <div class="col-lg-3 col-md-3 col-sm-12 mb-4">
        <div class="card" style="height: 70vh;">
            <div class="card-header border-bottom">
                    <h6 class="m-0">All Chats</h6>
            </div>
            <div class="card-body p-0">
                <ul class="list-group">
                  <?php $__empty_1 = true; $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <a href="<?php echo e(route('dashboard.messages.index')); ?>?user=<?php echo e($chat->user()->id); ?>" style="color:#3D5170;">
                  <li class="list-group-item <?php echo e(($message_to_user->id === $chat->user()->id)?'bg-primary text-white':''); ?>">
                    <p>
                      <i class="material-icons">person_pin</i>
                      <strong><?php echo e(ucwords($chat->user()->full_name)); ?></strong>
                    </p>
                  </li>
                  </a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <li class="list-group-item bg-primary text-white">
                    <p class="text-center">
                      No Chats Found
                    </p>
                  </li>
                  <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-lg-9 col-md-9 col-sm-12 mb-4">
      <div class="card" style="height: 70vh;">
        <div class="card-header border-bottom d-flex flex-row justify-content-between">
          <div class="chat-target-name">
            <h6 class="m-0">
              <?php if(isset($message_to_user) && $message_to_user !== null): ?>
              <?php echo e(ucwords($message_to_user->full_name)); ?>

              <?php else: ?>
              Choose a user to start chat
              <?php endif; ?>
            </h6>
          </div>
          <div class="choose-user-to-chat">
            <form action="<?php echo e(route('dashboard.messages.index')); ?>" class="form-inline" method="GET">
              <div class="form-group mr-1">
                <select name="user" id="" class="form-control">
                  <option value="" selected disabled>--Choose User to Chat--</option>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($user->id); ?>"><?php echo e(ucwords($user->full_name)); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group">
                <button class="btn btn-sm btn-primary" type="submit">Start Chat</button>
              </div>
            </form>
          </div>
        </div>
        <div class="card-body p-4" style="overflow-y: scroll;">
          <div class="chat-history" id="chathistoryDiv">
            
          </div>
        </div>
        <div class="card-footer" id="messageActions">
          <div class="container-fluid w-100">
            <div class="row">
              <div class="col-md-11">
                <textarea name="" rows="2" class="form-control" placeholder="Type your message here..." id="messageText"></textarea>
              </div>
              <div class="col-md-1 d-flex flex-column-reverse">
                <input type="hidden" id="user_from_id" value="<?php echo e(Auth::id()); ?>">
                <input type="hidden" id="user_to_id" value="<?php echo e((!blank($message_to_user))?$message_to_user->id:''); ?>">
                <input type="hidden" id="getChatHistoryRoute" value="<?php echo e(route('dashboard.messages.getchathistory')); ?>">
                <button class="btn btn-sm btn-success" id="sendMessageBtn" data-route="<?php echo e(route('dashboard.messages.send')); ?>">Send</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_scripts'); ?>
<script src="<?php echo e(asset('irh_assets/js/MessagesHandler.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /Users/Mac/Sites/irh/resources/views/dashboard/messages/index.blade.php */ ?>