<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Subscriber;
use Newsletter;
use Session;

class NewsLetterController extends Controller
{
	private $subscriberModel = null;

	public function __construct()
	{
		$this->subscriberModel = new Subscriber();
	}

    public function subscribe(Request $request)
    {
		$customMessages = ['email.unique' => 'You have already subscribed to our newsletter' ];
        $request->validate(['email'=>'required|unique:subscribers'],$customMessages);
        $this->subscriberModel->subscribeToNewsletter($request->email);
        Newsletter::subscribe($request->email,[],'subscribersList');
        Session::flash('success','You have Successfully Subscribe to Our NewsLetter');
    	return redirect()->back();
    }


    public function subscribers()
    {
        $subscribers = Subscriber::all();
        return view('dashboard.subscribers')->withSubscribers($subscribers);
    }

    public function unsubscribe(Subscriber $subscriber)
    {
        Newsletter::unsubscribe($subscriber->email,'subscribersList');
        $subscriber->delete();
        Session::flash('success','Newsletter Subscription Removed Successfully!');
        return redirect()->back();
    }

}
